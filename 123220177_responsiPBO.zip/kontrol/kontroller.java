/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontrol;

import java.util.List;
import DAOsewa_buku.sewa_bukuDAO;
import DAOimplement.sewa_bukuimplement;
import model.*;
import GUI.mainGUI;

public class kontroller {
    mainGUI frame;
    sewa_bukuimplement sbimpl;
    List<sewa_buku> sb;
    
    public kontroller(mainGUI frame){
        this.frame = frame;
        sbimpl = new sewa_bukuDAO();
        sb = sbimpl.getAll();
    }
    
    public void isiTabel(){
        sb = sbimpl.getAll();
        modeltabelsewa_buku mt = new modeltabelsewa_buku(sb);
        frame.gettabelsewa_buku().setmodel(mt);
    }
}
