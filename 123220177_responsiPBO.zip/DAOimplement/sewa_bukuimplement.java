/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOimplement;

import java.util.List;
import model.*;

public interface sewa_bukuimplement {
    
    public void insert(sewa_buku d);
    public void update(sewa_buku p);
    public void delete(Integer id);
    public List<sewa_buku>getAll();
    
}
