/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOsewa_buku;

import java.sql.*;
import java.util.*;
import koneksi.konektor;
import model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAOimplement.sewa_bukuimplement;

public class sewa_bukuDAO implements sewa_bukuimplement{
    
    Connection connect;
    
    final String select = "SELECT * FROM BOOKSTORE1";
    
    @Override
    public void insert(sewa_buku sw){
        PreparedStatement statement = null;
        try{
            String insert = null;
            statement = connect.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, d.getnama_penyewa);
            statement.setString(1, d.getjudul_buku);
            statement.setString(1, d.getjenis_buku);
            statement.setString(1, d.getnomor_telepon);
            statement.setInt(1, d.getdurasi_sewa);
            statement.setInt(1, d.gettotalbiaya);
            while (rs.next){
                d.setId(rs.getInt(1));
            }
            statement = connect.prepareStatement(update, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, p.getnama_penyewa);
            statement.setString(1, p.getjudul_buku);
            statement.setString(1, p.getjenis_buku);
            statement.setString(1, p.getnomor_telepon);
            statement.setInt(1, p.getdurasi_sewa);
            statement.setInt(1, p.gettotalbiaya);
            while(rs.next){
                p.setId(rs.getInt(1));
            }
            statement = connect.prepareStatement(delete, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, id.getnama_penyewa);
            statement.setString(1, id.getjudul_buku);
            statement.setString(1, id.getjenis_buku);
            statement.setString(1, id.getnomor_telepon);
            statement.setInt(1, id.getdurasi_sewa);
            statement.setInt(1, id.gettotalbiaya);
            while(rs.next){
                id.setId(rs.getInt(1));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
            System.out.println("GAGAL MENGOPERASIKAN TABEL");
        }
    }
}
