/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author PC PRAKTIKUM
 */
public class sewa_buku {
    
    private Integer id;
    private String nama_penyewa;
    private String nama_buku;
    private String jenis_buku;
    private String nomor_telp;
    private Integer durasi_sewa;
    private Integer total_biaya;
    int biaya;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNama_penyewa() {
        return nama_penyewa;
    }

    public void setNama_penyewa(String nama_penyewa) {
        this.nama_penyewa = nama_penyewa;
    }

    public String getNama_buku() {
        return nama_buku;
    }

    public void setNama_buku(String nama_buku) {
        this.nama_buku = nama_buku;
    }

    public String getJenis_buku() {
        return jenis_buku;
    }

    public void setJenis_buku(String jenis_buku) {
        this.jenis_buku = jenis_buku;
    }

    public String getNomor_telp() {
        return nomor_telp;
    }

    public void setNomor_telp(String nomor_telp) {
        this.nomor_telp = nomor_telp;
    }

    public Integer getDurasi_sewa() {
        return durasi_sewa;
    }

    public void setDurasi_sewa(Integer durasi_sewa) {
        this.durasi_sewa = durasi_sewa;
        if(durasi_sewa == 2){
            biaya = 10000;
        }
        else{
            biaya + 5000*durasi;
        }
    }

    public Integer getTotal_biaya() {
        return total_biaya;
    }

    public void setTotal_biaya(Integer total_biaya) {
        this.total_biaya = total_biaya;
    }
    
    
    
}
